
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import modelo.CSVSerializable;
import modelo.Personaje;


public class ArchivadoraCSV {
    public static void guardarPersonajesCSV(List<? extends CSVSerializable> inventario, String path){
        File archivo = new File(path);
        
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(archivo))){
                bw.write("ID,nombre,clase,nivel\n");
                for(CSVSerializable csv: inventario){
                    bw.write(csv.toCSV() + "\n");
                }
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
    }
    
    public static List<Personaje> cargarPersonajesCSV(String path){
        List<Personaje> toReturn = new LinkedList<>();
        File archivo = new File(path);
        
        try(BufferedReader br = new BufferedReader(new FileReader(archivo))){
            String linea;
            br.readLine();
            while((linea = br.readLine()) != null){
                if(linea.endsWith("\n")){
                    linea = linea.substring(linea.length() -1);
                }
                toReturn.add(Personaje.fromCSV(linea));
                }
        }catch(IOException ex){
            System.out.println(ex.getMessage());
        }
        return toReturn;
    }
}
