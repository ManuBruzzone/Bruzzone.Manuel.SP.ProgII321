
package modelo;


public class YaExisteElItemException extends RuntimeException{
    private static final String MESSAGE = "El item ya existe!";
    
    public YaExisteElItemException(){
        super(MESSAGE);
    }
}