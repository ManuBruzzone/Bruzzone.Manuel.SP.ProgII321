
package modelo;

import java.util.Objects;


public class Personaje implements Comparable<Personaje>, CSVSerializable{
    private int ID;
    private String nombre;
    private Clase clase;
    private int nivel;

    public Personaje(int ID, String nombre, Clase clase, int nivel) {
        this.ID = ID;
        this.nombre = nombre;
        this.clase = clase;
        this.nivel = nivel;
    }

    public Clase getClase() {
        return clase;
    }

    public void setNivel(int nivel) {
        this.nivel = nivel;
    }
    
    public int getNivel() {
        return nivel;
    }

    @Override
    public String toString() {
        return "ID: " + ID + ", Nombre: " + nombre + ", Clase: " + clase + ", Nivel: " + nivel;
    }

    @Override
    public int compareTo(Personaje p) {
        return nombre.compareTo(p.nombre);
    }
    
    @Override
    public boolean equals(Object o){
        if(o == null){
            return false;
        }
        if(o instanceof Personaje p){
            return Integer.compare(ID, p.ID) == 0;
        }
        if(o instanceof Clase c){
            return clase.equals(c);
        }
        return false;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + this.ID;
        hash = 37 * hash + Objects.hashCode(this.clase);
        return hash;
    }

    @Override
    public String toCSV() {
        return ID + "," + nombre + "," + clase + "," + nivel;
    }
    
    public static Personaje fromCSV(String path){
        Personaje toReturn = null;
        
        String[] values = path.split(",");
                if (values.length == 4) {
                    int ID = Integer.parseInt(values[0]);
                    String nombre = values[1];
                    Clase clase = Clase.valueOf(values[2]);
                    int nivel = Integer.parseInt(values[3]);
                    
                    toReturn = new Personaje(ID, nombre, clase, nivel);
        }
        return toReturn;
    }
}
