
package modelo;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public interface Inventariable <T> {
    
    void agregar(T item);
    
    void eliminar(int indice);
    
    List<T> filtrar(Predicate<? super T> criterio);
    
    void listar();
    
    void paraCadaElemento(Consumidora<? super T> tarea);
    
    void ordenarContenido(Comparator<? super T> comparador);
    
    void ordenarContenido();
    
    List<T> transformar(Function<? super T, ? extends T> transformacion);
}
