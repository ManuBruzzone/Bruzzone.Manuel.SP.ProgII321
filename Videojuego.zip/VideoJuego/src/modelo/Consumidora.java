
package modelo;

@FunctionalInterface
public interface Consumidora<T> {
    void usar(T o);
}
