
package modelo;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import service.ArchivadoraCSV;
import service.Serializadora;


public class Inventario <T> implements Inventariable <T>, Iterable<T>{
    
    private List<T> items = new LinkedList<>();

    @Override
    public void agregar(T item) {
        if(item == null){
            throw new IllegalArgumentException("Valor nulo");
        }
        if(!yaExiste(item)){
            items.add(item);
            System.out.println("Se agrego correctamente el contenido al inventario!");
        }
    }
    
    private boolean yaExiste(T item){
        if (items.contains(item)) {
            throw new YaExisteElItemException();
        }
        return false;
    }

    @Override
    public void eliminar(int indice) {
        if (indice >= 0 && indice < items.size()) {
        items.remove(indice);
        } else {
            System.out.println("Indice fuera de rango!");
        }
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for(T item: items){
            if(criterio.test(item)){
               toReturn.add(item);
                }
            }
        return toReturn;
    }
    
    @Override
    public void listar(){
        System.out.println("Listar empleados: ");
        for(T p: items){
            System.out.println(p);
        }
    }

    @Override
    public void paraCadaElemento(Consumidora<? super T> tarea) {
        for (T item : items){
            tarea.usar(item);
        }
    }

    @Override
    public Iterator<T> iterator(){
        if(!items.isEmpty() && items.get(0) instanceof Comparable){
            return iterator((Comparator<? super T>) Comparator.naturalOrder());
        }
        return items.iterator();
    }
        
    public Iterator<T> iterator(Comparator<? super T> comparador){
            items.sort(comparador);
            return items.iterator();
        } 
    
    @Override
    public void ordenarContenido(){
        ordenarContenido((Comparator<? super T>) (Comparator.naturalOrder()));
    }
    
    @Override
    public void ordenarContenido(Comparator<? super T> comparador){
        iterator(comparador);
    }    

    @Override
    public List<T> transformar(Function<? super T, ? extends T> transformacion) {
        List<T> toReturn = new ArrayList<>();
        for(T item: items){
            toReturn.add(transformacion.apply(item));
            }
        return toReturn;
    }
    
    public void guardarEnArchivo(String path) {
    List<CSVSerializable> itemsSerializables = new LinkedList<>();

    for (T item : items) {
        if (item instanceof CSVSerializable serializableItem) {
            itemsSerializables.add(serializableItem);
        }
    }
    if (!itemsSerializables.isEmpty()) {
        Serializadora.serializarPersonajes(itemsSerializables, path);
    } else {
        System.out.println("No hay elementos serializables para guardar.");
        }
    }
    
    public void guardarEnCSV(String path){
    List<CSVSerializable> itemsSerializables = new LinkedList<>();
    
    for (T item : items) {
        if (item instanceof CSVSerializable serializableItem) {
            itemsSerializables.add(serializableItem);
        }
    }
    if (!itemsSerializables.isEmpty()) {
        ArchivadoraCSV.guardarPersonajesCSV(itemsSerializables, path);
        System.out.println("\nElementos cargados correctamente en el archivo csv.");
        
    } else {
        System.out.println("\nNo hay elementos aptos para el csv.");
        }
    }
    
    public List<Personaje> cargarDesdeArchivo(String path) {
    List<Personaje> personajes = Serializadora.deserializarPersonajes(path);

    if (personajes == null || personajes.isEmpty()) {
        System.out.println("\nNo se encontraron Personajes en el archivo.");
        personajes = new LinkedList<>();
    } else {
        
        System.out.println("\nPersonajes cargados exitosamente.");
        for (Personaje personaje : personajes) {
            this.agregar((T)personaje);
        }
    }
    return personajes;
    }
    
    public List<Personaje> cargarDesdeCSV(String path, Consumidora<? super T> tarea){
        List<Personaje> personajes = ArchivadoraCSV.cargarPersonajesCSV(path);

        if (personajes == null || personajes.isEmpty()) {
            System.out.println("\nNo se encontraron personajes en el archivo.");
            personajes = new LinkedList<>();
        } else {
            checkearContenido(tarea);
            
            System.out.println("\nPersonajes cargados exitosamente.");
            for (Personaje personaje : personajes) {
                this.agregar((T) personaje);
            }
        }
        return personajes;
    }
    
    private void checkearContenido(Consumidora<? super T> tarea){
        if (!items.isEmpty()) {
            System.out.println("\nEl inventario no esta vacio. Eliminando elementos existentes para poder cargar los datos... ");
            List<T> itemsCopia = new ArrayList<>(items);

            for (T item : itemsCopia) {
                tarea.usar(item);
            }
            System.out.println("Elementos eliminados");
        }  
    }
}